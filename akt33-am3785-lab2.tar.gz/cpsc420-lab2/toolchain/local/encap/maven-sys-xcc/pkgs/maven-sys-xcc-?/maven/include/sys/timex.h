//========================================================================
// timex.h : Extra timing utilities
//========================================================================

#ifndef _SYS_TIMEX_H_
#define _SYS_TIMEX_H_

#include <machine/timex.h>

#endif
