#ifndef _SCHED_H_
#define _SCHED_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/sched.h>

#ifdef __cplusplus
}
#endif

#endif /* _SCHED_H_ */
